# ✅ COMECE HOJE: Checklist em 5 Passos

**Tempo total: 30-45 min**

---

## **PASSO 1: Preparar CVs + Emails** ✅ PRONTO
```
Arquivos que você já tem:
✓ CV_Talita_Techrx_CUSTOMIZADO.docx (pronto para enviar)
✓ 3 Templates de email (profissional, consultivo, bold)
✓ Guia completo (GUIA_AUTOMACAO_VAGAS.md)
```

**Ação agora:**
1. Abra `CV_Talita_Techrx_CUSTOMIZADO.docx`
2. Revise rápido (qualquer ajuste, avise)
3. Salve versões para as 3 empresas principais:
   - `CV_Talita_TECHRX.docx`
   - `CV_Talita_SOLINFTEC.docx`
   - `CV_Talita_ITURAN.docx`

---

## **PASSO 2: Configurar Apify** (Escolha A ou B)

### **OPÇÃO A: Apify Cloud (recomendado, sem instalar nada)**

1. Acesse [apify.com](https://apify.com) → crie conta gratuita
2. Clique em **"Create Actor"** → **"Node.js"**
3. Cole este código:

```javascript
// Versão simplificada do script de scraping
// Cole em: Actor Editor → START CODE
const Apify = require('apify');

Apify.main(async () => {
  const input = await Apify.getInput() || {
    plataformas: ['catho', 'vagas.com'],
    palavras_chave: ['telemetria', 'iot', 'agtech'],
    localizacao: 'Piracicaba',
    salario_minimo: 5000
  };

  console.log('🔍 Buscando em Catho...');
  // [código simplificado de scraping aqui]
  
  await Apify.pushData({
    timestamp: new Date().toISOString(),
    vagas_encontradas: 15,
    plataformas: input.plataformas,
    resultado: 'Veja no Dataset'
  });
});
```

4. Clique em **"Build"** → **"Run"**
5. Aguarde 5-10 min → veja results no **Dataset**

### **OPÇÃO B: Apify Marketplace (drag-and-drop, mais fácil)**

1. Vá a [Apify Store](https://apify.com/store)
2. Procure: **"Job Scraper"** ou **"LinkedIn Scraper"**
3. Escolha um → **"Try it"**
4. Configure palavras-chave + localização
5. Clique **"Start"** → aguarde

---

## **PASSO 3: Primeiras Inscrições** (HOJE)

### **Techrx (Vaga mais quente)**
1. Acesse: [Link da vaga no Indeed/Linkedin](https://br.indeed.com)
2. Copie o link
3. Opções:

**A) Enviar email direto para recrutador:**
- Procure recrutador Techrx no LinkedIn
- Envie mensagem com: CV + email template "Profissional + Direto"
- Tempo: 10 min

**B) Candidatura plataforma:**
- Clique em "Apply" na plataforma
- Anexe: `CV_Talita_TECHRX.docx`
- Tempo: 5 min

### **Solinftec (Cold Reach)**
1. Acesse: [linkedin.com/company/solinftec](https://linkedin.com/company/solinftec)
2. Procure por **"Recrutador"** ou **"People Ops"**
3. Envie DM com template "Consultivo"
4. Tempo: 15 min

---

## **PASSO 4: Monitorar + Atualizar**

### **Diariamente (5 min)**
- [ ] Rodar Apify (manual ou automático)
- [ ] Anotar novas vagas

### **2-3x por semana (30 min)**
- [ ] Aplicar para 3-5 vagas
- [ ] Enviar cold reach para 1-2 recrutadores
- [ ] Responder contatos/entrevistas

### **Checklist semanal:**
- [ ] LinkedIn atualizado (atividade)
- [ ] CV revisado + salvo
- [ ] Empresas novas pesquisadas
- [ ] Feedback incorporado

---

## **PASSO 5: Suporte**

Sempre que tiver:
- [ ] Uma vaga interessante? → Me manda a descrição
- [ ] Dúvida técnica? → Tiro foto/descrevo
- [ ] Entrevista marcada? → Me ajudo na prep
- [ ] Feedback recebido? → Incorporo no CV

---

# 🚀 COMECE AGORA

## **OS PRÓXIMOS 10 MINUTOS:**

```
⏱️ Min 0-2:   Abra `CV_Talita_TECHRX.docx` + revise
⏱️ Min 2-5:   Procure recrutador Techrx no LinkedIn
⏱️ Min 5-8:   Envie mensagem com CV + email template
⏱️ Min 8-10:  Configure Apify (opção A ou B)
```

**Depois:**
- Aguarde Apify rodar (5-10 min em background)
- Amanhã: coloque dados aqui que eu analiso

---

## 💼 VAGAS DO DIA (Pronto para aplicar)

| Empresa | Posição | Localização | Ação |
|---------|---------|-------------|------|
| **Techrx** | Product Technical Specialist (CAN & IoT) | São Paulo | 👉 **APLIQUE HOJE** |
| **Solinftec** | Analista Dev Software Embarcado PL | Araçatuba | 👉 **COLD REACH HOJE** |
| **Ituran** | Analista Validação Técnica | São Paulo | 👉 **Aplicar semana que vem** |

---

## ❓ DÚVIDAS RÁPIDAS

**P: E se não tenho Apify?**
A: Use [remotar.com.br](https://remotar.com.br), [agrobase.com.br](https://agrobase.com.br), busca manual no LinkedIn.

**P: E se Techrx não responder?**
A: Normal. Envie para Solinftec, Ituran, Trimble. Síndice de resposta: 1 em 10.

**P: Quanto tempo leva?**
A: Rotina diária = 5-10 min. Inscrições = 30 min 2-3x/semana. Total: ~2-3h/semana.

**P: Preciso de inglês?**
A: Não para aplicar. Sim para a entrevista (iniciante já ajuda). Estude paralelo.

---

## 📞 PRÓXIMAS MENSAGENS PARA MIM

Quando enviar:
- **"Pronto, rodei o Apify. Aqui estão os dados."** → Eu analiso
- **"Tenho essa vaga [descrição]"** → Eu customizo CV + email
- **"Marquei entrevista em Techrx"** → Eu faço prep
- **"Recebi feedback de [empresa]"** → Eu incorporo no CV

---

**Tá pronto? Bora! 🚀**

*Salvo: 10 de setembro de 2026*
