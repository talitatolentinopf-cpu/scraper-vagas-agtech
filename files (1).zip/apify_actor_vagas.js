/**
 * Apify Actor - Scraping de Vagas (Agtech/Telemetria/IoT)
 * Executa buscas em múltiplas plataformas e retorna vagas organizadas
 * 
 * INPUT ESPERADO:
 * {
 *   "plataformas": ["linkedin", "catho", "vagas.com"],
 *   "palavras_chave": ["telemetria", "iot", "agtech"],
 *   "localizacao": "Piracicaba",
 *   "salario_minimo": 5000,
 *   "max_resultados": 50
 * }
 */

const Apify = require('apify');

Apify.main(async () => {
  const input = await Apify.getInput();
  
  const {
    plataformas = ['catho', 'vagas.com'],
    palavras_chave = ['telemetria', 'iot', 'agtech', 'sistemas embarcados'],
    localizacao = 'Piracicaba',
    salario_minimo = 5000,
    max_resultados = 50
  } = input;

  const vagas = [];

  // ============================================
  // CATHO.COM.BR
  // ============================================
  if (plataformas.includes('catho')) {
    console.log('🔍 Buscando em Catho...');
    
    const browser = await Apify.launchPuppeteer();
    
    for (const keyword of palavras_chave) {
      const page = await browser.newPage();
      try {
        const url = `https://www.catho.com.br/vagas?q=${encodeURIComponent(keyword)}&l=${encodeURIComponent(localizacao)}`;
        await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
        
        // Aguardar vagas carregarem
        await page.waitForSelector('[data-testid="job-card"]', { timeout: 10000 }).catch(() => null);
        
        const vagasCatho = await page.evaluate(() => {
          const cards = document.querySelectorAll('[data-testid="job-card"]');
          return Array.from(cards).slice(0, 15).map(card => ({
            titulo: card.querySelector('a')?.textContent?.trim() || '',
            empresa: card.querySelector('[data-testid="company-name"]')?.textContent?.trim() || '',
            localizacao: card.querySelector('[data-testid="job-location"]')?.textContent?.trim() || '',
            link: card.querySelector('a')?.href || '',
            plataforma: 'catho',
            salario: card.querySelector('[data-testid="job-salary"]')?.textContent?.trim() || '',
            data_postagem: new Date().toISOString()
          })).filter(v => v.titulo && v.empresa);
        });
        
        vagas.push(...vagasCatho);
        console.log(`✅ Catho: ${vagasCatho.length} vagas encontradas com "${keyword}"`);
        
      } catch (err) {
        console.log(`⚠️ Erro em Catho com "${keyword}": ${err.message}`);
      } finally {
        await page.close();
      }
    }
    
    await browser.close();
  }

  // ============================================
  // VAGAS.COM.BR
  // ============================================
  if (plataformas.includes('vagas.com')) {
    console.log('🔍 Buscando em Vagas.com...');
    
    const browser = await Apify.launchPuppeteer();
    
    for (const keyword of palavras_chave) {
      const page = await browser.newPage();
      try {
        const url = `https://www.vagas.com.br/vagas/${encodeURIComponent(keyword)}/${encodeURIComponent(localizacao)}`;
        await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
        
        await page.waitForSelector('[class*="jobcard"]', { timeout: 10000 }).catch(() => null);
        
        const vagasVagas = await page.evaluate(() => {
          const cards = document.querySelectorAll('[class*="jobcard"]');
          return Array.from(cards).slice(0, 15).map(card => ({
            titulo: card.querySelector('h2')?.textContent?.trim() || '',
            empresa: card.querySelector('[class*="company"]')?.textContent?.trim() || '',
            localizacao: card.querySelector('[class*="location"]')?.textContent?.trim() || '',
            link: card.querySelector('a')?.href || '',
            plataforma: 'vagas.com',
            salario: card.querySelector('[class*="salary"]')?.textContent?.trim() || '',
            data_postagem: new Date().toISOString()
          })).filter(v => v.titulo && v.empresa);
        });
        
        vagas.push(...vagasVagas);
        console.log(`✅ Vagas.com: ${vagasVagas.length} vagas encontradas com "${keyword}"`);
        
      } catch (err) {
        console.log(`⚠️ Erro em Vagas.com com "${keyword}": ${err.message}`);
      } finally {
        await page.close();
      }
    }
    
    await browser.close();
  }

  // ============================================
  // LINKEDIN (Cuidado com rate limit)
  // ============================================
  if (plataformas.includes('linkedin')) {
    console.log('🔍 Buscando em LinkedIn (cuidado: pode ser lento)...');
    
    const browser = await Apify.launchPuppeteer();
    const page = await browser.newPage();
    
    try {
      // LinkedIn é mais restritivo, então usar queries genéricas
      const url = `https://www.linkedin.com/jobs/search/?keywords=telemetria%20IoT&location=${encodeURIComponent(localizacao)}&geoId=`;
      
      await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
      await page.waitForSelector('[class*="job-card"]', { timeout: 15000 }).catch(() => null);
      
      const vagasLinkedIn = await page.evaluate(() => {
        const cards = document.querySelectorAll('[class*="job-card"]');
        return Array.from(cards).slice(0, 10).map(card => ({
          titulo: card.querySelector('h3')?.textContent?.trim() || '',
          empresa: card.querySelector('[class*="company-name"]')?.textContent?.trim() || '',
          localizacao: card.querySelector('[class*="job-search-card__location"]')?.textContent?.trim() || '',
          link: card.querySelector('a')?.href || '',
          plataforma: 'linkedin',
          salario: 'Não disponível',
          data_postagem: new Date().toISOString()
        })).filter(v => v.titulo && v.empresa);
      });
      
      vagas.push(...vagasLinkedIn);
      console.log(`✅ LinkedIn: ${vagasLinkedIn.length} vagas encontradas`);
      
    } catch (err) {
      console.log(`⚠️ Erro em LinkedIn: ${err.message}`);
    } finally {
      await page.close();
      await browser.close();
    }
  }

  // ============================================
  // PROCESSAMENTO FINAL
  // ============================================
  
  // Remover duplicatas
  const vagasUnicas = Array.from(
    new Map(vagas.map(v => [v.link || v.titulo, v])).values()
  );

  // Ordenar por data
  vagasUnicas.sort((a, b) => new Date(b.data_postagem) - new Date(a.data_postagem));

  // Limitar ao máximo solicitado
  const vagasFinais = vagasUnicas.slice(0, max_resultados);

  console.log(`\n📊 RESULTADO FINAL: ${vagasFinais.length} vagas extraídas\n`);

  // Salvar no dataset do Apify
  await Apify.pushData({
    timestamp: new Date().toISOString(),
    filtros: { plataformas, palavras_chave, localizacao, salario_minimo },
    total_vagas: vagasFinais.length,
    vagas: vagasFinais
  });

  console.log('✅ Dados salvos! Pronto para análise.');
});
