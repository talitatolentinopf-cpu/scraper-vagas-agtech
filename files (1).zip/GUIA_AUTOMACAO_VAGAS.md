# 🚀 GUIA: Automação de Busca + Inscrição em Vagas (Apify + Claude)

**Objetivo:** Buscar vagas em agtech/telemetria/IoT automaticamente, analisar match com seu perfil, gerar CVs customizados e facilitar inscrições.

---

## 📋 O Que Já Foi Feito

✅ **CV Customizado para Techrx** → `CV_Talita_Techrx_CUSTOMIZADO.docx`
- Reordenado para Product Technical Specialist (CAN & IoT)
- Foco em: CAN bus, sistemas embarcados, validação técnica
- Números-chave destacados

✅ **3 Email Templates** (para recrutadores)
- Versão Profissional + Direto
- Versão Consultiva (com curiosidade técnica)
- Versão Bold (foco em números)

✅ **Apify Actor Template** → `apify_actor_vagas.js`
- Scraping de Catho, Vagas.com, LinkedIn
- Filtro por localização, salário, palavras-chave
- Retorna dados organizados para análise

---

## 🎯 FLUXO AUTOMÁTICO (4 PASSOS)

### **Passo 1: Configurar o Apify Actor**

#### Opção A: Usar Apify Cloud (recomendado)
1. Crie conta em [apify.com](https://apify.com)
2. Clique em **"Create Actor"** → escolha **"Node.js"**
3. Cole o código de `apify_actor_vagas.js` no editor
4. Configure o **Input JSON** com:

```json
{
  "plataformas": ["catho", "vagas.com", "linkedin"],
  "palavras_chave": ["telemetria", "iot", "agtech", "sistemas embarcados", "CAN bus"],
  "localizacao": "Piracicaba",
  "salario_minimo": 5000,
  "max_resultados": 50
}
```

5. Clique em **"Build"** e depois **"Run"**
6. Aguarde 5-10 minutos (pode ser lento em LinkedIn)
7. Copie os dados do **Dataset** (Output)

#### Opção B: Executar localmente
```bash
cd /home/claude
npm install apify puppeteer docx
node apify_actor_vagas.js
```

---

### **Passo 2: Enviar Dados para Claude**

1. Copie o JSON retornado pelo Apify
2. Cole nesta chat com: **"Analisa as vagas que o Apify trouxe"**
3. Eu vou:
   - 🔍 Filtrar por match com seu CV
   - 📊 Rankear por relevância (1-5 ⭐)
   - 💼 Agrupar por empresa
   - 📝 Sugerir ações (aplicar, cold reach, etc)

---

### **Passo 3: Gerar CV + Email Customizados**

Para cada vaga promissora, você pode:

**a) Pedir CV Customizado**
```
"Gera um CV customizado para a vaga de Product Manager na Solinftec"
```
→ Recebe Word doc pronto para enviar

**b) Pedir Email Personalizado**
```
"Cria 2 versões de email para contatar o recrutador da Techrx"
```
→ Recebe 2-3 variações de abordagem

---

### **Passo 4: Inscrição Automática**

#### 🟢 FÁCIL (Apify trata)
- **Catho**: inscrição via API (precisa de token)
- **Vagas.com**: inscrição via API (precisa de token)
- **Linkdin**: aplicação manual (por segurança)

#### 🟡 INTERMEDIÁRIO (Manual + Auto)
- Gero email → você copia/cola no LinkedIn Recruiter
- Gero mensagem → você manda DM pro recrutador

#### 🔴 COMPLEXO (100% Manual)
- Captura de formulário (não vale a pena automatizar)
- Você clica o link e preenche

---

## 📅 ROTINA RECOMENDADA

### **Diariamente (15 min)**
1. Roda Apify (automático ou manual)
2. Envia dados para Claude
3. Recebe ranking + análise

### **2-3x por Semana (30-45 min)**
1. Aplica para 3-5 vagas top
2. Manda cold reach (email/DM) para 2 recrutadores
3. Monitora respostas

### **1x por Semana (1h)**
1. Atualiza CV conforme feedback
2. Otimiza palavras-chave (se necessário)
3. Pesquisa empresas novas

---

## 🎯 VAGAS PRIORITÁRIAS (COMEÇAR AGORA)

| Empresa | Posição | Local | Status | Ação |
|---------|---------|--------|--------|------|
| **Techrx** | Product Technical Specialist (CAN & IoT) | São Paulo, SP | 🟢 TOP | Enviar CV + Email |
| **Solinftec** | Analista Dev Software Embarcado PL | Araçatuba, SP | 🟢 TOP | Cold Reach |
| **Solinftec** | Analista Dev Hardware PL | Araçatuba, SP | 🟢 TOP | Cold Reach |
| **Ituran** | Analista Validação Técnica | São Paulo, SP | 🟡 BOA | Investigar |

---

## 📧 TEMPLATES PRONTOS

### **Email 1: Techrx (Profissional)**
Sujeito: `Candidatura: Product Technical Specialist (CAN & IoT) - Talita Tolentino`

[Ver opções de email acima]

### **Email 2: Solinftec (Cold Reach)**
Sujeito: `Expertise em Telemetria/Solinftec — Talita Tolentino`

```
Olá [recrutador/equipe técnica],

Sou Talita, especialista em telemetria e sistemas embarcados com forte experiência em Solinftec (implementação em Usina Ipiranga, 2020-2021).

Meu background:
- 10+ anos em telemetria veicular e IoT agrícola
- Experiência direta com Trimble, Maxtrack, Solinftec
- Validação técnica de 4.000 veículos (94,8% redução de risco)
- Liderança técnica e treinamento em larga escala

Interesse atual: transição para papel estratégico em engenharia ou product management de plataformas IoT/telemetria.

Faz sentido uma conversa? Envio currículo ou call rápida conforme preferência.

Abraço,
Talita
(19) 99322-7319
```

---

## 🔧 TROUBLESHOOTING

### **"Apify não conseguiu scrape LinkedIn"**
- LinkedIn é muito restritivo com bots
- Solução: focar em Catho + Vagas.com + Indeed
- LinkedIn = backup ou busca manual

### **"Não achei vaga no meu tema/localização"**
- Expanda para: remoto, São Paulo inteira, interior
- Adicione palavras-chave: "embedded", "firmware", "IoT", "automação"
- Busque em: Aerobase, OLX Jobs, JoinData, GuPy

### **"Quantas vagas sairão?"**
- Realista: 5-20 por semana em agtech/IoT (São Paulo)
- Solinftec + Trimble + agtech startups = 2-3 novas vagas/mês
- Foco: qualidade > quantidade

---

## 💡 DICAS EXTRAS

### **Para aumentar chances:**
1. **Inglês** é diferencial → estude básico (3 meses)
2. **LinkedIn atualizado** → adicione habilidades novas
3. **GitHub/Portfolio** → mesmo que conceitual (ajuda em tech roles)
4. **Certificados** → Product Management, IoT, AI (gratuitos: Coursera)

### **Empresas-alvo adicionais:**
- Trimble (São Paulo)
- AGCO/JohnDeere (São Paulo)
- TerraMagna (São Paulo)
- Strider (São Paulo)
- Aegro (São Paulo)
- Inari (São Paulo)
- Climate FieldView (Brasil)

---

## 📞 PRÓXIMOS PASSOS

1. **Hoje**: Escolha entre Apify Cloud ou executar localmente
2. **Amanhã**: Configure input + rode primeira busca
3. **Esta semana**: Envie CVs + emails para Techrx + Solinftec
4. **Próximas semanas**: Rotina de 2-3x por semana

---

## 📞 APOIO

Sempre que precisar:
- Análise de vaga específica
- CV customizado
- Email personalizado
- Prep de entrevista
- Mapeamento de empresas

**Mande direto:** "Tenho essa vaga" + description

---

*Criado em: 10 de setembro de 2026*
*Customizado para: Talita Tolentino — Transição de Supervisor de Qualidade para Product/Tech Manager em Telemetria*
